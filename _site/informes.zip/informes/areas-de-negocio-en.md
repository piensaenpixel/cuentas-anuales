---
layout: default
title: Áreas de negocio
lang: en
submenu: gestion
order: 2
permalink: informe-de-gestion/areas-de-negocio/
---
