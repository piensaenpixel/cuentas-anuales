---
layout: default
title: Información
lang: en
submenu: gestion
order: 4
permalink: informe-de-gestion/informacion/
---
